<?php
	
	/**
	 * Clase: Index_Modelo
	 */
	class Index_Modelo extends Modelo {
		
		/**
		 * Metodo: Constructor
		 */
		function __Construct() {
			parent::__Construct();
		}
		
		/**
		 * Metodo: Ejemplo
		 */
		public function ConsultaSQL() {
			
		}
	}